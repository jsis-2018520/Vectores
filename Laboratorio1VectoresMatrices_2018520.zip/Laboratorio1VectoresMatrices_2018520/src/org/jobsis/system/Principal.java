/*
    Nombre: Job Willka Sis Rodríguez
    Codigo Tecnico: IN5AV
    Carnet: 2018520
    Fecha de Creacion; 27-03-2022
    Fecha de modificacion: 28-03-2022
 */
package org.jobsis.system;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] vectorDato1 = new int[10];
        int[] vectorDato2 = new int[10];
        int[] vectorResultSum = new int[10];
        int[] vectorResultRes = new int[10];
        
        int[][] matrizDato1 = new int[3][3];
        int[][] matrizDato2 = new int[3][3];
        int[][] matrizResultSum = new int[3][3];
        int[][] matrizResultRes = new int[3][3];
        
        int opcion;
        char decision='s';        
        System.out.println("Bienvenido");
        
        while (decision == 's'){
            System.out.println("Elige tu opcion");
            System.out.println("1.Vectores");
            System.out.println("2.Matrices");
            System.out.println("3.Salir");
            opcion = sc.nextInt();
            switch(opcion){
                case 1:
                    System.out.println("Vector 1 Datos");
                    for(int i=0; i< vectorDato1.length; i++){
                        System.out.println("Ingrese un dato");
                        vectorDato1[i] = sc.nextInt();
                    }
        
                    System.out.println("Vector 2 Datos");
                    for(int i=0; i<vectorDato2.length; i++){
                        System.out.println("Ingrese un dato");
                        vectorDato2[i] = sc.nextInt();
                    }

                    for(int i=0; i<vectorDato1.length;i++){
                        int valor1;
                        int valor2;
                        int result;
                        valor1 = vectorDato1[i]; 
                        valor2 = vectorDato2[i];
                        result = valor1 + valor2;
                        vectorResultSum[i] = result;
                    }
                    
                    for(int i=0; i<vectorDato1.length;i++){
                        int valor1;
                        int valor2;
                        int result;
                        valor1 = vectorDato1[i]; 
                        valor2 = vectorDato2[i];
                        result = valor1 - valor2;
                        vectorResultRes[i] = result;
                    }           
                    
                    System.out.println("Suma de los valores de los vectores");
                    for(int cont=0; cont<vectorDato1.length;cont++){
                        int valor1;
                        int valor2;
                        int result;
                        valor1 = vectorDato1[cont]; 
                        valor2 = vectorDato2[cont];
                        result = vectorResultSum[cont];
                        System.out.println(valor1+" + "+valor2+" = "+result);
                    }


                    
                    System.out.println("Resta de los valores de los vectores");
                    for(int cont=0; cont<vectorDato1.length;cont++){
                        int valor1;
                        int valor2;
                        int result;
                        valor1 = vectorDato1[cont]; 
                        valor2 = vectorDato2[cont];
                        result = vectorResultRes[cont];
                        System.out.println(valor1+" - "+valor2+" = "+result);
                    }
                    break;
                case 2:
                    //-----Matrices
                    System.out.println("Matriz 1 Dato");
                    for(int i=0;i<matrizDato1.length;i++){
                        for(int j=0;j<matrizDato2.length;j++){
                            System.out.println("Ingrese un valor");
                            matrizDato1[i][j] = sc.nextInt();
                        }
                    }
                    
                    System.out.println("Matriz 2 Dato");
                    for(int i=0;i<matrizDato2.length;i++){
                        for(int j=0;j<matrizDato2.length;j++){
                            System.out.println("Ingrese un valor");
                            matrizDato2[i][j] = sc.nextInt();
                        }
                    }   

                    for(int i=0;i<matrizDato1.length;i++){
                        for(int j=0;j<matrizDato1.length;j++){
                            int valor1;
                            int valor2;
                            int result;
                            valor1 = matrizDato1[i][j];
                            valor2 = matrizDato2[i][j];
                            result = valor1 + valor2;
                            matrizResultSum[i][j] = result;
                        }
                    }
                    
                    for(int i=0;i<matrizDato1.length;i++){
                        for(int j=0;j<matrizDato1.length;j++){
                            int valor1;
                            int valor2;
                            int result;
                            valor1 = matrizDato1[i][j];
                            valor2 = matrizDato2[i][j];
                            result = valor1 - valor2;
                            matrizResultRes[i][j] = result;
                        }
                    }                    
                    
                    System.out.println("Suma de los valores de las matrices");
                    for(int i=0;i<matrizDato1.length;i++){
                        for(int j=0;j<matrizDato1.length;j++){
                            int valor1;
                            int valor2;
                            int result;
                            valor1 = matrizDato1[i][j];
                            valor2 = matrizDato2[i][j];
                            result = matrizResultSum[i][j];
                            System.out.println(valor1+" + "+valor2+" = "+result);
                        }
                    }
        
                    System.out.println("Resta de los valores de las matrices");
                    for(int i=0;i<matrizDato1.length;i++){
                        for(int j=0;j<matrizDato1.length;j++){
                            int valor1;
                            int valor2;
                            int result;
                            valor1 = matrizDato1[i][j];
                            valor2 = matrizDato2[i][j];
                            result = matrizResultRes[i][j];
                            System.out.println(valor1+" - "+valor2+" = "+result);
                        }
                    }                
                    break;
                case 3:
                    System.out.println("Gracias por su preferencia :>");
                    System.exit(0);
                default:
                    System.out.println("Elige una opcion correcta");
                    break;
                
            } 
            System.out.println("Desea Continuar");
            System.out.println("si = s o no = n");
            String x = sc.next();
            decision = x.charAt(0);
        }
        System.out.println("Gracias por su preferencia :>");
    }  
}
